<?php $__env->startSection('title', 'Settings'); ?>
<?php $__env->startSection('css'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container m-auto">

        <h1 class="text-2xl leading-none text-gray-900 tracking-tight mt-3"> Account Setting </h1>
        <ul class="mt-5 -mr-3 flex-nowrap lg:overflow-hidden overflow-x-scroll uk-tab">
            <li class="uk-active"><a href="#">General</a></li>
            <li><a href="#">Profile</a></li>
            <li><a href="#">Privacy</a></li>
            <li><a href="#">Notification</a></li>
            <li><a href="#">Social links</a></li>
            <li><a href="#">Billing</a></li>
            <li><a href="#">Security</a></li>
        </ul>

        <div class="grid lg:grid-cols-3 mt-12 gap-8">
            <div>
                <h3 class="text-xl mb-2"> Basic</h3>
            </div>
            <div class="bg-white rounded-md lg:shadow-lg shadow col-span-2">
                <form action="<?php echo e(route('updateUser')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="grid grid-cols-2 gap-3 lg:p-6 p-4">
                    <div>
                        <label for=""> First name</label>
                        <input type="text" name="firstname" value="<?php echo e(auth()->user()->firstname); ?>" placeholder="Your name.." class="shadow-none bg-gray-100" style="<?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border:1px solid red <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="uk-text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for=""> Last name</label>
                        <input type="text" name="lastname" value="<?php echo e(auth()->user()->lastname); ?>" placeholder="Your name.." class="shadow-none bg-gray-100" style="<?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border:1px solid red <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="uk-text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-span-2">
                        <label for="">Email</label>
                        <input type="text" disabled value="<?php echo e(auth()->user()->email); ?>" class="shadow-none bg-gray-100">
                    </div>
                    <div class="col-span-2">
                        <label for="about">About me</label>
                        <textarea id="about" name="description" style="padding:20px; resize:none;  <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border:1px solid red <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3" class="shadow-none bg-gray-100"><?php echo e(auth()->user()->description); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="uk-text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-span-2">
                        <label for="picture"> <img style="max-width:100px;" src="assets/images/profiles/<?php echo e(auth()->user()->userpicture); ?>" /></label>
                        <input type="file" id="picture" name="picture" style="display:none;" />
                        <input type="button"  id="pictureBtn" class="button bg-blue-700" value="Browse" />
                    </div>
                </div>

                <div class="bg-gray-10 p-6 pt-0 flex justify-end space-x-3">
                    <button type="reset" class="p-2 px-4 rounded bg-gray-50 text-red-500"> Cancel </button>
                    <button type="submit" class="button bg-blue-700"> Save </button>
                </div>
                </form>






            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php if( session('status') ): ?>
<script>
UIkit.notification({message: '<?php echo e(session("status")); ?>', status: 'success'});
</script>
<?php endif; ?>

<script>
    $("#pictureBtn").click(function(){
        //alert("ok");
        $("#picture").click();
    })
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.homeLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instello-Laravel\resources\views/settings.blade.php ENDPATH**/ ?>